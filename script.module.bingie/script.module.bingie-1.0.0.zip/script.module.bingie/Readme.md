# script.module.bingie

Common code required by TMDb Bingie Helper.
