# script.bingie.widgets

Widgets for Bingie skin.
